<?php get_header(); ?>

<div id="loop-container" class="loop-container">
  <?php woocommerce_content(); ?>
</div>

<?php get_footer();