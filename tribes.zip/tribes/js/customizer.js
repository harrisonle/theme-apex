jQuery(document).ready(function($){
    $('#accordion-section-tribes_display').find('.customize-section-description').appendTo('#customize-control-display_post_date');
});